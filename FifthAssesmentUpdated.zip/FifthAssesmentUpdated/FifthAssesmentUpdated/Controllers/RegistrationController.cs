﻿using Core;
using Domain;
using Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Net;
using System.Net.Mail;

namespace FifthAssesmentUpdated.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IPasswordHasher<Registration> _passwordHasher;
        private readonly IConfiguration _config;
        private readonly IEmailService _emailService;
        private static Dictionary<string, string> _otpStorage = new Dictionary<string, string>();

        public RegistrationController(AppDbContext context, IPasswordHasher<Registration> passwordHasher, IConfiguration config, IEmailService emailService)
        {
            _context = context;
            _passwordHasher = passwordHasher;
            _config = config;
            _emailService = emailService;
        }

        [AllowAnonymous]
        [HttpPost("CreateUser")]
        public IActionResult Create(Registration user)
        {
            user.Password = _passwordHasher.HashPassword(user, user.Password);
            user.CreatedOn = DateTime.Now;
            _context.registrations.Add(user);
            _context.SaveChanges();
            return Ok("success");
        }


        [AllowAnonymous]
        [HttpPost("LoginUser")]
        public async Task<IActionResult> Login(Login login)
        {
            var userAvailable = _context.registrations.Where(u => u.Email == login.Email).FirstOrDefault();
            
            if (userAvailable != null)
            {
                var res = _passwordHasher.VerifyHashedPassword(userAvailable, userAvailable.Password, login.Password);
                if (res == PasswordVerificationResult.Success)
                {
                    var otp = GenerateOtp();
                    _otpStorage[login.Email] = otp;


                    await _emailService.SendEmailAsync(login.Email, "Your OTP Code", $"Your OTP code is {otp}");
                    return Ok("OTP sent to email");
                    //return Ok(new JwtService(_config).GenerateToken(userAvailable.Id, userAvailable.FirstName, userAvailable.LastName, userAvailable.Email));
                }
            }

            return Ok("Failure");
        }

        [AllowAnonymous]
        [HttpPost("VerifyOtp")]
        public IActionResult VerifyOtp(OtpVerification otpVerification)
        {
            if (_otpStorage.ContainsKey(otpVerification.Email) && _otpStorage[otpVerification.Email] == otpVerification.Otp)
            {
                _otpStorage.Remove(otpVerification.Email); // Remove OTP after successful verification
                var user = _context.registrations.Where(u => u.Email == otpVerification.Email).FirstOrDefault();
                return Ok(new JwtService(_config).GenerateToken(user.Id, user.FirstName, user.LastName, user.Email));
            }
            return Ok("Invalid OTP");
        }


        private string GenerateOtp()
        {
            var rng = new Random(); return rng.Next(100000, 999999).ToString();
           
        }
        //private async Task SendOtpEmail(string email, string otp) {
        //    var apiKey = _config["SendGridApiKey"]; 
        //    var client = new SendGridClient(apiKey); 
        //    var from = new EmailAddress("davisiduardo@gmail.com", "Siddharth");
        //    var subject = "Your OTP Code"; 
        //    var to = new EmailAddress(email); 
        //    var plainTextContent = $"Your OTP code is {otp}"; 
        //    var htmlContent = $"<strong>Your OTP code is {otp}</strong>";
        //    var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
        //    var response = await client.SendEmailAsync(msg);
        //    Console.WriteLine($"SendGrid Response StatusCode: {response.StatusCode}");
        //    Console.WriteLine($"SendGrid Response Body: {await response.Body.ReadAsStringAsync()}");
        //}
        
    }

}

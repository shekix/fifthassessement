import { Routes } from '@angular/router';
import { RegistrationComponent } from '../components/registration/registration.component';
import { LoginComponent } from '../components/login/login.component';
import { NotfoundComponent } from '../components/notfound/notfound.component';
import { HomeComponent } from '../components/home/home.component';
import { authguardGuard } from '../components/authguard.guard';
import { OtpComponent } from '../components/otp/otp.component';

export const routes: Routes = [
    {
        path:'',
        component:RegistrationComponent
    },
    {
        path:'register',
        component:RegistrationComponent
    },
    {
        path:'login',
        component:LoginComponent
    },
    
    {
        path:'home',
        component:HomeComponent,
        canActivate:[authguardGuard]
    },
    {
        path:'otp',
        component:OtpComponent
    },
    {
        path:'**',
        component:NotfoundComponent
    }
];
